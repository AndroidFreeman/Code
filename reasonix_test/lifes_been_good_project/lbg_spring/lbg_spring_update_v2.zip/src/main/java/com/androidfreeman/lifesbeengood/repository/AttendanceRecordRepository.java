package com.androidfreeman.lifesbeengood.repository;

import com.androidfreeman.lifesbeengood.model.AttendanceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AttendanceRecordRepository extends JpaRepository<AttendanceRecord, String> {
}
