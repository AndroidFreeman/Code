package com.androidfreeman.lifesbeengood.controller;

import com.androidfreeman.lifesbeengood.controller.ApiResponse;
import com.androidfreeman.lifesbeengood.model.AttendanceRecord;
import com.androidfreeman.lifesbeengood.model.AttendanceSession;
import com.androidfreeman.lifesbeengood.model.Student;
import com.androidfreeman.lifesbeengood.repository.AttendanceRecordRepository;
import com.androidfreeman.lifesbeengood.repository.AttendanceSessionRepository;
import com.androidfreeman.lifesbeengood.repository.StudentRepository;
import com.androidfreeman.lifesbeengood.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api/attendance")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AttendanceController {

    @Autowired private AttendanceSessionRepository attendanceSessionRepository;
    @Autowired private AttendanceRecordRepository attendanceRecordRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private EventService eventService;

    @GetMapping("/sessions")
    public ApiResponse<List<AttendanceSession>> listAttendanceSessions() {
        return ApiResponse.success(attendanceSessionRepository.findAll());
    }

    @GetMapping("/records")
    public ApiResponse<List<AttendanceRecord>> listAttendanceRecords() {
        return ApiResponse.success(attendanceRecordRepository.findAll());
    }

    @PostMapping("/sessions")
    public ApiResponse<Map<String, String>> startAttendanceSession(@RequestBody AttendanceSession session) {
        String id = "as_" + System.currentTimeMillis();
        session.setId(id);
        session.setStartedAt(java.time.Instant.now().toString());
        attendanceSessionRepository.save(session);
        eventService.emitModulesChanged("attendance");
        return ApiResponse.success(Map.of("session_id", id, "started_at", session.getStartedAt()));
    }

    @PostMapping("/records")
    public ApiResponse<AttendanceRecord> markAttendanceRecord(@RequestBody AttendanceRecord record) {
        AttendanceRecord saved = attendanceRecordRepository.save(record);
        eventService.emitModulesChanged("attendance");
        return ApiResponse.success(saved);
    }

    @PostMapping("/recognize")
    public ApiResponse<List<String>> recognizeFace(@RequestParam("file") MultipartFile file, @RequestParam("sessionId") String sessionId) {
        List<Student> allStudents = studentRepository.findAll();
        if (allStudents.isEmpty()) {
            return ApiResponse.success(Collections.emptyList());
        }
        Random rand = new Random();
        int index = rand.nextInt(allStudents.size());
        Student recognizedStudent = allStudents.get(index);
        return ApiResponse.success(Collections.singletonList(recognizedStudent.getId()));
    }
}